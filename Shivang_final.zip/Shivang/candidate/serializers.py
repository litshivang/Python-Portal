# Candidate/serializers.py

from rest_framework import serializers
from django.contrib.auth.models import User
from Shivang.models import CustomUser
from django.contrib.auth import get_user_model

from candidate.models import CandidateApplication, Job, JobApplication
from hr.models import HRJob
  # Import the custom user model


User = get_user_model()  # Get the custom user model

class CandidateRegistrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser  # Use the custom user model
        fields = ('username', 'password', 'email', 'first_name', 'last_name')
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        user = User.objects.create_user(**validated_data)
        return user

class HRJobSerializer(serializers.ModelSerializer):
    class Meta:
        model = HRJob
        fields = '__all__'  # You can specify fields explicitly if needed

class JobApplicationSerializer(serializers.ModelSerializer):
    class Meta:
        model = JobApplication
        fields = ['resume','name']


class CandidateApplicationSerializer(serializers.ModelSerializer):
    class Meta:
        model = CandidateApplication
        fields = ['resume'] 