# candidate/urls.py

from django.urls import path
from .views import  ApplyJobView, CandidateRegistrationView, CandidateLoginView, ApprovedJobList
from Shivang import settings
from django.conf.urls.static import static

urlpatterns = [
    path('register/', CandidateRegistrationView.as_view(), name='candidate-register'),
    path('login/', CandidateLoginView.as_view(), name='candidate-login'),
    path('approved-jobs/', ApprovedJobList.as_view(), name='approved-job-list'),
    # path('apply-job/<int:job_id>/', JobApplicationCreate.as_view(), name='apply-job'),
    path('apply/<int:job_id>/', ApplyJobView.as_view(), name='apply-job'),
]

# if settings.DEBUG:
#     urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)