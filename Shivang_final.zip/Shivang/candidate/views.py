# Candidate/views.py
from django.shortcuts import get_object_or_404
from rest_framework.authtoken.models import Token
from django.contrib.auth import authenticate
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status,generics
from rest_framework.response import Response
from Shivang.models import CustomUser
from hr.models import HRJob
from rest_framework import generics, permissions, serializers, status
from .models import Job, JobApplication
from hr.serializers import HRJobSerializer, JobSerializer
from .serializers import CandidateApplicationSerializer, CandidateRegistrationSerializer, JobApplicationSerializer
from rest_framework import generics, status,permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.parsers import MultiPartParser


class CandidateRegistrationView(generics.CreateAPIView):
    serializer_class = CandidateRegistrationSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            user.role = 'Candidate'  # Set the user's role
            user.save()
            return Response({'message': 'Candidate registration successful.'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class CandidateLoginView(APIView):
    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')
        user = authenticate(username=username, password=password)

        if user:
            token, _ = Token.objects.get_or_create(user=user)
            return Response({'token': token.key}, status=status.HTTP_200_OK)
        else:
            return Response({'message': 'Invalid credentials.'}, status=status.HTTP_401_UNAUTHORIZED)


# class JobApplicationCreate(generics.CreateAPIView):
#     serializer_class = JobApplicationSerializer
#     permission_classes = [permissions.IsAuthenticated]

#     def create(self, request, *args, **kwargs):
#         # Extract the job_id from the URL
#         job_id = kwargs.get('job_id')
#         job = get_object_or_404(HRJob, id=job_id, approved=True)

#         # Check if the user has already applied for this job
#         if JobApplication.objects.filter(candidate=self.request.user, job=job).exists():
#             return Response({"detail": "You have already applied for this job."}, status=status.HTTP_400_BAD_REQUEST)

#         # Create a dictionary containing the candidate and job data
#         data = {
#             'candidate': self.request.user.id,  # Automatically extract the candidate from the request user
#             'job': job_id,
#             'resume': self.request.data.get('resume')  # Assuming resume is still sent in the request data
#         }

#         serializer = self.get_serializer(data=data)
#         serializer.is_valid(raise_exception=True)
#         serializer.save()

#         return Response({"detail": "You have applied successfully."}, status=status.HTTP_201_CREATED)
    
class ApprovedJobList(generics.ListAPIView):
    queryset = HRJob.objects.filter(approved=True)
    serializer_class = HRJobSerializer
    permission_classes = [permissions.AllowAny]


class ApplyJobView(generics.CreateAPIView):
    serializer_class = CandidateApplicationSerializer

    def create(self, request, job_id):
        try:
            print(f"job_id: {job_id}")
            # Fetch the job with the given job_id
            job = HRJob.objects.get(pk=job_id)

            print(f"job_id: {job_id}")
            print(f"Found job: {job}")

            # Check if the job is approved
            if not job.approved:
                return Response({"detail": "Job is not approved"}, status=status.HTTP_400_BAD_REQUEST)

            # Create a candidate application
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            
            # Use your custom user model for the candidate
            serializer.save(job=job, candidate=request.user)

            return Response(serializer.data, status=status.HTTP_201_CREATED)

        except Job.DoesNotExist:
            return Response({"detail": "Job does not exist"}, status=status.HTTP_404_NOT_FOUND)