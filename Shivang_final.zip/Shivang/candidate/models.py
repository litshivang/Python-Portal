from django.db import models
from Shivang.models import CustomUser
from hr.models import HRJob
from django.conf import settings
from rest_framework import serializers
from django.db import models
from hr.models import HRJob
from django.db import models
from django.contrib.auth.models import User
 # Import the Job model

class Job(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    required_experience = models.CharField(max_length=100)
    status = models.BooleanField(default=False)

    # Define the user who created the job
    created_by = models.ForeignKey(
        CustomUser,
        on_delete=models.CASCADE,
        related_name='created_jobs'  # Unique related_name for created jobs
    )

    # Define the user who posted the job
    posted_by = models.ForeignKey(
        CustomUser,
        on_delete=models.CASCADE,
        related_name='posted_jobs'  # Unique related_name for posted jobs
    )

    created_at = models.DateTimeField(auto_now_add=True)
    approved = models.BooleanField(default=False)

    # ManyToManyField to User model for tracking candidate applications
    candidates_applied = models.ManyToManyField(
        'Shivang.CustomUser',
        related_name='applied_jobs',
        through='JobApplication'
    )

    def __str__(self):
        return self.title


class JobApplication(models.Model):
    job = models.ForeignKey('Job', on_delete=models.CASCADE)
    candidate = models.ForeignKey(CustomUser, on_delete=models.CASCADE)  # Use your custom user model here
    resume = models.FileField(upload_to='resumes/')
    applied_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.candidate.username} applied for {self.job.title}"

# candidate/models.py


class CandidateApplication(models.Model):
    job = models.ForeignKey(HRJob, on_delete=models.CASCADE)
    candidate = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    resume = models.FileField(upload_to='resumes/')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Application for {self.job.title} by {self.candidate.username}"
