from django.contrib import admin
from django.urls import path, include
from Shivang import settings
from django.conf.urls.static import static
from dj_rest_auth import urls as rest_auth_urls


urlpatterns = [
    path('admin/', admin.site.urls),
    path('hr/', include('hr.urls')),
    path('admin_panel/', include('admin_panel.urls')),
    path('candidate/', include('candidate.urls')),
    # path('auth/', include('dj_rest_auth.urls')),

    path('password_reset/', include('django.contrib.auth.urls')),
    path('password_reset/done/', include('django.contrib.auth.urls')),
    path('reset/<uidb64>/<token>/', include('django.contrib.auth.urls')),
    path('reset/done/', include('django.contrib.auth.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)


