from django.db import models
from Shivang import settings
from Shivang.models import CustomUser



class HRJob(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    required_experience = models.CharField(max_length=100)
    status = models.BooleanField(default=False)
    
    created_by = models.ForeignKey(
        CustomUser,
        on_delete=models.CASCADE,
        related_name='hr_jobs_created'  # Unique related_name for HR jobs
    )
    posted_by = models.ForeignKey(
        CustomUser,
        on_delete=models.CASCADE,
        related_name='hr_jobs_posted'  # Unique related_name for HR posted jobs
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    approved = models.BooleanField(default=False)
    
    # Define the many-to-many relationship with CustomUser
    candidates_applied = models.ManyToManyField(
        'Shivang.CustomUser',
        related_name='hr_applied_jobs',
        through='HRJobApplication',

    )

    def __str__(self):
        return self.title

class HRJobApplication(models.Model):
    job = models.ForeignKey('hr.HRJob', on_delete=models.CASCADE)
    candidate = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    # Add other fields as needed

    class Meta:
        unique_together = ('job', 'candidate')