# hr/serializers.py
from rest_framework import serializers
from .models import HRJob
from rest_framework import serializers
from django.contrib.auth import get_user_model  # Import the custom user model
from django.contrib.auth.tokens import default_token_generator
from django.contrib.auth import views as auth_views
from rest_framework import generics, status
from rest_framework.response import Response
from Shivang.models import CustomUser
# CustomUser = get_user_model()  # Get the custom user model
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode 


class HRRegistrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser  # Use CustomUser instead of User
        fields = ('username', 'password', 'email', 'first_name', 'last_name')
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        user = CustomUser.objects.create_user(**validated_data)  # Use CustomUser manager
        return user
    
class JobSerializer(serializers.ModelSerializer):
    created_by = serializers.PrimaryKeyRelatedField(queryset=CustomUser.objects.all())  # Specify BooleanField with required=False
    candidates = serializers.PrimaryKeyRelatedField(many=True, read_only=True)

    class Meta:
        model = HRJob
        fields = '__all__'

class HRJobSerializer(serializers.ModelSerializer):
    applications = serializers.PrimaryKeyRelatedField(many=True, read_only=True)

    class Meta:
        model = HRJob
        fields = '__all__'

class PasswordResetSerializer(serializers.Serializer):
    email = serializers.EmailField()

    def validate_email(self, value):
        # Check if the email exists in the database
        try:
            user = CustomUser.objects.get(email=value)
        except CustomUser.DoesNotExist:
            raise serializers.ValidationError("Email does not exist in our records.")
        
        # Retrieve the existing token if it exists
        existing_token = user.password_reset_token  # Replace with the actual field name

        if not existing_token:
            raise serializers.ValidationError("No existing password reset token found.")

        # Generate a reset link using the existing token
        uid = urlsafe_base64_encode(force_bytes(user.pk))
        token = existing_token  # Use the existing token
        
        # Return the user and token
        return user, uid, token