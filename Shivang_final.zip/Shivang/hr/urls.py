# hr/urls.py

from django.urls import path
from .views import HRRegistrationView, HRLoginView, HRPostJobView, HRUserListView, PasswordResetRequestView

urlpatterns = [
    path('register/', HRRegistrationView.as_view(), name='hr-register'),
    path('login/', HRLoginView.as_view(), name='hr-login'),
    path('post-job/', HRPostJobView.as_view(), name='hr-post-job'),
    # path('hr-users/', HRUserListView.as_view(), name='hr-user-list'),
    # path('password_reset/', CustomPasswordResetView.as_view(), name='password_reset'),
    # path('password_reset/confirm/<uidb64>/<token>/', CustomPasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('password-reset/', PasswordResetRequestView.as_view(), name='password_reset_request'),
]
