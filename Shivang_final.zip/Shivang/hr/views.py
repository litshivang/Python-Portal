# hr/views.py
from rest_framework.authtoken.models import Token
from django.contrib.auth import authenticate
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework import generics
from rest_framework.response import Response
from rest_framework import status
from Shivang.models import CustomUser
# from candidate.models import JobApplication
# from candidate.serializers import JobApplicationSerializer
from hr.permissions import IsHRUser
from .serializers import HRJobSerializer, HRRegistrationSerializer
from rest_framework import generics
from rest_framework import permissions
from rest_framework.response import Response
from rest_framework import status
from .models import HRJob
from .serializers import JobSerializer
from django.contrib.auth.views import PasswordResetView
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth.views import PasswordResetConfirmView
from django.contrib.auth.tokens import default_token_generator
from django.contrib.auth import views as auth_views
from rest_framework import generics, status
from rest_framework.response import Response
from .serializers import PasswordResetSerializer
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes
from django.urls import reverse
from django.core.mail import send_mail


class HRRegistrationView(generics.CreateAPIView):
    serializer_class = HRRegistrationSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            user.role = 'HR'  # Set the user's role
            user.save()
            return Response({'message': 'HR registration successful.'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class HRUserListView(APIView):
    permission_classes = [IsHRUser]

    def get(self, request):
        # Retrieve HR users
        hr_users = CustomUser.objects.filter(role='HR')
        
        # Extract user IDs
        hr_user_ids = [user.id for user in hr_users]

        return Response({'hr_user_ids': hr_user_ids})
    
class HRLoginView(APIView):
    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')
        user = authenticate(username=username, password=password)

        if user:
            token, _ = Token.objects.get_or_create(user=user)
            return Response({'token': token.key}, status=status.HTTP_200_OK)
        else:
            return Response({'message': 'Invalid credentials.'}, status=status.HTTP_401_UNAUTHORIZED)
        
        
from rest_framework.authtoken.models import Token

class HRPostJobView(generics.CreateAPIView):
    serializer_class = JobSerializer
    permission_classes = [permissions.IsAuthenticated, IsHRUser]

    def create(self, request, *args, **kwargs):
        # Retrieve the HR user from the token
        try:
            token = request.auth
            hr_user = Token.objects.get(key=token).user
        except Token.DoesNotExist:
            return Response({'message': 'HR user not found.'}, status=status.HTTP_404_NOT_FOUND)

        # Set the "posted_by" field to the HR user
        request.data['posted_by'] = hr_user.id

        # Set the "created_by" field to the HR user
        request.data['created_by'] = hr_user.id

        # Set the status to "pending approval" when HR creates a job
        request.data['status'] = True  # Use a boolean value

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)  # Validate the serializer with required fields
        job = serializer.save()

        # Serialize the created job and include it in the response
        job_serializer = JobSerializer(job)

        return Response({
            'message': 'Job posted successfully.',
            'job': job_serializer.data  # Include the job details in the response
        }, status=status.HTTP_201_CREATED)

class HRJobDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = HRJob.objects.all()
    serializer_class = HRJobSerializer



class PasswordResetRequestView(generics.CreateAPIView):
    serializer_class = PasswordResetSerializer

    def create(self, request, *args, **kwargs):
        email = request.data.get('email')
        User = CustomUser
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response({'detail': 'User not found.'}, status=status.HTTP_400_BAD_REQUEST)
        
        uid = urlsafe_base64_encode(force_bytes(user.pk))
        token = default_token_generator.make_token(user)
        reset_url = reverse('password_reset_confirm', kwargs={'uidb64': uid, 'token': token})
        reset_link = request.build_absolute_uri(reset_url)
        
        # Send the reset link via email
        subject = 'Password Reset'
        message = f'Click the following link to reset your password: {reset_link}'
        from_email = 'workshivang@gmail.com'  # Replace with your email address
        recipient_list = [email]
        
        try:
            send_mail(subject, message, from_email, recipient_list, fail_silently=False)
        except Exception as e:
            return Response({'detail': 'Failed to send reset email.'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        return Response({'detail': 'Password reset link sent successfully.'}, status=status.HTTP_200_OK)