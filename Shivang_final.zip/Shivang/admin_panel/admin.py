# admin/admin.py

from django.contrib import admin
from .models import AdminJob

# Register the AdminJob model
admin.site.register(AdminJob)
