# Admin/serializers.py

from rest_framework import serializers
from django.contrib.auth.models import User

from Shivang.models import CustomUser
from hr.models import HRJob
from .models import AdminJob
from django.contrib.auth import get_user_model

User = get_user_model()  # Get the custom user model

class AdminRegistrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser  # Use the custom user model
        fields = ('username', 'password', 'email', 'first_name', 'last_name')
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        user = User.objects.create_user(**validated_data)
        return user

class AdminJobSerializer(serializers.ModelSerializer):
    class Meta:
        model = AdminJob
        fields = '__all__'
        read_only_fields = ('approved',)
        
class AdminAndHRJobSerializer(serializers.ModelSerializer):
    class Meta:
        model = None  # The model will be determined dynamically
        fields = '__all__'

    def to_representation(self, instance):
        # Determine the type of job and serialize accordingly
        if isinstance(instance, AdminJob):
            self.Meta.model = AdminJob
        elif isinstance(instance, HRJob):
            self.Meta.model = HRJob

        return super().to_representation(instance)