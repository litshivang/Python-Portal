# admin/urls.py

from django.urls import path
from .views import AdminJobDetailView, AdminJobListView, AdminRegistrationView, AdminLoginView

urlpatterns = [
    path('register/', AdminRegistrationView.as_view(), name='admin-register'),
    path('login/', AdminLoginView.as_view(), name='admin-login'),
    path('jobs/', AdminJobListView.as_view(), name='admin-job-list'),
    path('jobs/<int:pk>/', AdminJobDetailView.as_view(), name='job-detail'),
]
