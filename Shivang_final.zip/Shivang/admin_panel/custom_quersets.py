# # admin_panel/custom_querysets.py

# from .models import AdminJob, HRJob

# class AdminAndHRJobQuerySet:
#     def combined_jobs(self):
#         return AdminJob.objects.all() | HRJob.objects.all()
