# Admin/views.py
from rest_framework.authtoken.models import Token
from django.contrib.auth import authenticate
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework import generics
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth.models import User
from Shivang.models import CustomUser
from admin_panel.permissions import IsAdminUser
from hr.models import HRJob
from hr.serializers import JobSerializer
from .serializers import AdminAndHRJobSerializer, AdminJobSerializer, AdminRegistrationSerializer
from rest_framework import generics
from rest_framework import permissions
from .models import AdminJob



class AdminRegistrationView(generics.CreateAPIView):
    serializer_class = AdminRegistrationSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            user.role = 'Admin'  # Set the user's role
            user.save()
            return Response({'message': 'Admin registration successful.'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class AdminLoginView(APIView):
    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')
        user = authenticate(username=username, password=password)

        if user:
            token, _ = Token.objects.get_or_create(user=user)
            return Response({'token': token.key}, status=status.HTTP_200_OK)
        else:
            return Response({'message': 'Invalid credentials.'}, status=status.HTTP_401_UNAUTHORIZED)

class AdminJobListView(generics.ListCreateAPIView):
    serializer_class = AdminAndHRJobSerializer
    permission_classes = [permissions.IsAuthenticated, IsAdminUser]

    def get_queryset(self):
        user = self.request.user
        if user.is_admin:  # Assuming you have an attribute or method to check if the user is an admin
            queryset = AdminJob.objects.all()
        else:
            queryset = HRJob.objects.all()
        return queryset

class AdminJobDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = HRJob.objects.all()
    serializer_class = AdminAndHRJobSerializer
    permission_classes = [permissions.IsAuthenticated, permissions.IsAdminUser]

    def update(self, request, *args, **kwargs):
        instance = self.get_object()
        if 'approved' in request.data:
            is_approved = request.data['approved']
            instance.approved = is_approved
            instance.save()
            return Response({'message': 'Job approval status updated successfully.'})
        else:
            return Response({'message': 'Please provide the "approved" field in the request.'}, status=status.HTTP_400_BAD_REQUEST)

