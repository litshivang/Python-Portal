# adminapp/models.py

from django.db import models
from Shivang.models import CustomUser 
from django.contrib.auth import get_user_model


class AdminJob(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    # Other job details fields
    approved = models.BooleanField(default=False)  # Indicates job approval status
    posted_by = models.ForeignKey(get_user_model(), on_delete=models.CASCADE, related_name='admin_jobs')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title